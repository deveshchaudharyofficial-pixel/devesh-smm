# Devesh SMM — free starter website

A mobile-friendly React/Vite demo for legitimate Instagram growth services. It includes:
- Service list and category filters
- Order form with basic Instagram URL validation
- Demo order tracking
- Demo customer-login preview
- Demo admin dashboard
- Dark purple responsive design

## Important limitations
This is a **front-end demo**, not a production SMM backend. Orders are stored only in the current browser's React state; reloading the page clears them. Customer login is not real authentication. The admin key `demo-admin` is a public demo-only key and is not secure. Do not collect real customer data or deploy these demo flows as a live business without replacing them with a secure backend, database, authentication, server-side validation, abuse controls, privacy policy, and appropriate payment handling.

The included services are strategy/content/analytics services, not fake followers, bot engagement, or guaranteed follower delivery. No Instagram password is requested.

## Run locally

1. Install Node.js LTS from https://nodejs.org
2. Extract this folder.
3. Open Terminal/Command Prompt inside the `devesh_smm_starter` folder.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL Vite prints (usually `http://localhost:5173`).

## Build for static hosting

```bash
npm run build
```

The production site is created in `dist/`.

## Free static deployment with Cloudflare Pages

1. Create a GitHub account at https://github.com and make a new repository.
2. Upload the files in this folder to the repository (do not upload `node_modules`).
3. Go to https://pages.cloudflare.com and connect the repository.
4. Use build command `npm run build` and output directory `dist`.
5. Deploy. Re-test on mobile.

Static hosting can publish this front-end, but it does not add a database, secure login, payment processing, or real order fulfillment.

## Before real launch
- Replace demo order state with a server-backed database.
- Use a trusted authentication provider; never store plaintext passwords.
- Protect admin routes and validate permissions on the server.
- Add privacy policy, terms, refund policy, contact details, and applicable business/legal compliance.
- Use legitimate, transparent services. Do not request Instagram passwords or one-time codes.
- If adding payments, use a reputable payment provider and verify payment server-side.
- Do not promise guaranteed follower counts or use bots/fake engagement.
